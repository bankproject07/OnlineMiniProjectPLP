package com.cg.obs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="User_Table")

public class Users {
	
	@Id
	@Column(name="user_id")
	private int userId;
	@Column(name="Account_ID")
	private Long accountId;
	@Column(name="login_password")
	private String loginPassword;
	@Column(name="secret_question")
	private String secretQuestion;
	@Column(name="secret_answer")
	private String secretAns;
	@Column(name="Transaction_password")
	private String transPassword;
	@Column(name="lock_status")
	private String lockStatus;

	public Users() 
	{
		super();
	}


	public Users(Long accountId, int userId, String loginPassword, String secretQuestion, String secretAns,
			String transPassword, String lockStatus) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.loginPassword = loginPassword;
		this.secretQuestion = secretQuestion;
		this.secretAns = secretAns;
		this.transPassword = transPassword;
		this.lockStatus = lockStatus;
	}


	public Users(int i, String string) {
		// TODO Auto-generated constructor stub
	}


	public String getSecretAns() {
		return secretAns;
	}


	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}


	public Long getAccountId() 
	{
		return accountId;
	}

	public void setAccountId(Long accountId)
	{
		this.accountId = accountId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	public String getLoginPassword()
	{
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword)
	{
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() 
	{
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) 
	{
		this.secretQuestion = secretQuestion;
	}

	public String getTransPassword() 
	{
		return transPassword;
	}

	public void setTransPassword(String transPassword) 
	{
		this.transPassword = transPassword;
	}

	public String getLockStatus()
	{
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) 
	{
		this.lockStatus = lockStatus;
	}

	
	@Override
	public String toString() {
		return "Users [accountId=" + accountId + ", userId=" + userId + ", loginPassword=" + loginPassword
				+ ", secretQuestion=" + secretQuestion + ", secretAns=" + secretAns + ", transPassword=" + transPassword
				+ ", lockStatus=" + lockStatus + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + userId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Users other = (Users) obj;
		if (userId != other.userId)
			return false;
		return true;
	}





}

